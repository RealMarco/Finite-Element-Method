clear;
% A=0;B=0;
% a=0;b=0;
ju=input('ju');
if ju
    A=[1 2;3 4];
    B=[1 2 3; 4 5 6 ];
    a=1;b=2;
else
    A=0.1*[1 2;3 4];
    B=0.1*[1 2 3; 4 5 6 ];
    a=0.1;b=0.2;
end